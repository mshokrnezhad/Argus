# football-field-detection > 2024-08-19 7:51pm
https://universe.roboflow.com/roboflow-jvuqo/football-field-detection-f07vi

Provided by a Roboflow user
License: CC BY 4.0

